import React from 'react';
import {PostDetails} from './PostDetails.component';

class Album extends React.Component{
    render(){

            var allpostsinAlbum = this.props.myposts.map((p,index)=>{
                return <PostDetails {...this.props} i={index} postdetails ={p} key={index*Math.random()}/>
            });

        return <div>
            <h2 className="main"> Album Component </h2>
              <div className="container">  
                {allpostsinAlbum}
              </div>
            </div>
    }
}

export default Album;

