import React from 'react';

class Main extends React.Component {

    componentDidMount(){
        this.props.fetchTodosData();
    }

    render() {
        return <div>
            <h1 className="main"> Main Component </h1>
            <h1>{this.props.mytodos.length} </h1>
            {React.cloneElement(this.props.children,this.props)}
        </div>
    }
}

export default Main;

