import React from 'react';
import {PostDetails} from './PostDetails.component'

class Photo extends React.Component{
    render(){

        var code = this.props.params.codeId;
        var index = this.props.myposts.findIndex((post)=>{
           return post.code == code;
        });

        var currPost = this.props.myposts[index];
        return <div>
             <h2 className="main"> Photo Component </h2>
             <PostDetails postdetails = {currPost} i={index} {...this.props} />
            </div>
    }
}

export default Photo;

