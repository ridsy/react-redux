import React from 'react';
import {Link} from 'react-router'

export class PostDetails extends React.Component{

    render(){
             
           return   <div className="row postStyle">
               <div className="col-md-2">
               <Link to={`/photo/${this.props.postdetails.code}`}>         
                   <img src={this.props.postdetails.display_src} height="100%" width="100%" ></img>
                </Link>   
           </div>
           <div className="col-md-4">
               <b>{this.props.postdetails.caption}</b><br/>
               <button type="button" className="btn btn-primary" onClick={this.props.increment.bind(null,this.props.i)}>{this.props.postdetails.likes} <i className="glyphicon glyphicon-thumbs-up"></i></button>
            </div> 
            </div>
        
        
    }
}