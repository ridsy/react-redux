import {combineReducers} from 'redux';
import posts from './postsReducer';
import comments from './commentsReducer';
import todos from './todoReducer'


var rootReducer = combineReducers({
    posts,
    comments,
    todos
})

export default rootReducer;