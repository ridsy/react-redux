export default function fetchTodoReducer(state=[],action){

    switch(action.type){
        case 'FETCH_TODOS':
        return action.response;
        default:
        return state;
    }
}