import axios from 'axios'


export function fetchTodos(response){
    
        return {type:'FETCH_TODOS',response:response.data};
    }
    
    export function fetchTodosData(){
       
        console.log("Within fetchTodosData")
        var request = axios.get("https://jsonplaceholder.typicode.com/todos");
    
        return (dispatch)=>{
            request.then((response)=>{
             
                dispatch(fetchTodos(response))
            })
        }
    
            
    }