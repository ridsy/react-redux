import React from 'react';
import {Tododetails} from './Tododetails.component'

class TodoList extends React.Component{
    render(){

            var alltodos = this.props.mytodos.map((t,index)=>{
                return <Tododetails {...this.props} i={index} tododetail ={t} key={index*Math.random()}/>
            });

        return <div>
            <h2 className="main">TodoList</h2>
              <div className="container">  
                {alltodos}
              </div>
            </div>
    }
}

export default TodoList;