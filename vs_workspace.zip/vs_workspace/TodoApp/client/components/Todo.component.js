import React from 'react';

class Todo extends React.Component{
    render(){

        var id = this.props.params.id;
        var index = this.props.mytodos.findIndex((todo)=>{
           return todo.id == id;
        });

        var currTodo = this.props.mytodos[index];
        return <div className="panel panel-default main">
             <h2 className="panel-heading">Todo</h2>
             <div className="panel-body">
              <p><b>UserId:</b>{currTodo.userId}</p>
              <p><b>Id:</b>{currTodo.id}</p>
              <p><b>Title:</b>{currTodo.title}</p>
              <p><b>Completed:</b>{currTodo.completed.toString()}</p>
           </div>
            </div>
    }
}

export default Todo;
