import React from 'react';
import {Link} from 'react-router'

export class Tododetails extends React.Component{

    render(){
             
           return   <div className="row">
               <div className="col-md-4">
                   <ul>
                   <Link to={`/todo/${this.props.tododetail.id}`}>         
                       <li>{this.props.tododetail.title}</li>
                  </Link>  
                  </ul> 
               </div>
            </div>
        
        
    }
}