
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as allActions from '../actions/actions'
import Main from './Main.component';

function mapStateToProp(storeData){
    return{
        mytodos:storeData.todos
    }
}

function mapDispatchToProp(dispatch){
    return bindActionCreators(allActions,dispatch);
}

var wrapper = connect(mapStateToProp,mapDispatchToProp);
//console.log(wrapper);
var App=wrapper(Main);
export default App;