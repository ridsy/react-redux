export default function posts(state=[],action){
    switch(action.type){
        case 'INCREMENT_LIKES':
        console.log("Posts Reducer called !");
        return state;
        default:
        return state;
        
    }
}