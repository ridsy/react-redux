import React from 'react';

export class PostDetails extends React.Component{

    render(){
             
           return   <div className="row postStyle">
               <div className="col-md-2">
                   <img src={this.props.postdetails.display_src} height="100%" width="100%" ></img>
           </div>
           <div className="col-md-4">
               <b>{this.props.postdetails.caption}</b>
               <button type="button" className="btn btn-primary" >{this.props.postdetails.likes} <i className="glyphicon glyphicon-thumbs-up"></i></button>
            </div> 
            </div>
        
        
    }
}