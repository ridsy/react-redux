export function increment(index){
    return{
        type:'INCREMENT_LIKES',
        index
    }
}


export function addcomment(){
    return {
        type:'ADD_COMMENT'
    }
}