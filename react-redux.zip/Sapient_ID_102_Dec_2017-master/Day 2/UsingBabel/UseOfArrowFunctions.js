var Square = x =>  x * x;
console.log( Square(10));