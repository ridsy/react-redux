import Pie, {Add,Product} from './Math';

console.log('The addition is : ' + Add(20,30));