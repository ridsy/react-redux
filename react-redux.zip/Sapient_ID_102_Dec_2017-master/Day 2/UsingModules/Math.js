
// named Export !
 function Add(x,y){
        return x + y;
}

 function Product(x,y){
    return x * y;
}


const PI = 3.14;

export var BizObj={
    Addition:Add,
    Multiplication:Product
}

export default PI;